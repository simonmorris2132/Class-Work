package com.company;

@SuppressWarnings("ALL")

public class Main {

    public static void main(String[] args) {
        FindLargestNum.run();
    }
}
