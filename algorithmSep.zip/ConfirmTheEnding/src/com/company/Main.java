package com.company;

@SuppressWarnings("ALL")

public class Main {

    public static void main(String[] args) {
        System.out.println("The word is Bastion.");
        ConfirmTheEnding.run();
    }
}
