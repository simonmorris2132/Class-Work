package com.company;

//import java.util.Arrays;

public class WhereAmI {

    public static void run() {

        double[] arr = new double[] {1.0, 2.0, 3.0};
        double[] a = new double[] {3.5};

        for (double i = 0; i < arr.length; i++) {
            if (a[0] > arr[2]) {
                
            }
        }

    }

}
