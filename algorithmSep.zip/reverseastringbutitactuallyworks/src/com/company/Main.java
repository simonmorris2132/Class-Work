package com.company;

@SuppressWarnings("all")

public class Main {

    public static void main(String[] args) {
	reversethestring.run();
    }
}
