import java.util.Arrays;

public class WhereDoIBelong {

    public static void run() {

        int[] array = {1, 2, 3};
        int num = 4;

        Arrays.sort(array);
/* 
        for (int i = 2; i < array.length; i++) {

            if (num >= array[i]) {
                System.out.println("This is the index: " + num);
            } */
            
        }
    }


/* Here's the problem with this, the only thing i could find for this in the documentation and online was how to just return or print out the elements from the array. This challenge really shows how java and scripting can be way too convaluted at least in my opinion. */
