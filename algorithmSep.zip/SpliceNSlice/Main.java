@SuppressWarnings("ALL")

public class Main {

    public static void main(String[] args) {
        SpliceAndSlice.run();
    }
    
}
