package com.company;

@SuppressWarnings("All")

public class Main {

    public static void main(String[] args) {
        FindTheLongestWord.run();
    }
}
