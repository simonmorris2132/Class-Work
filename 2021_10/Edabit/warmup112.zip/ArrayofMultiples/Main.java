package Edabit.ArrayofMultiples;

public class Main {
    public static void main(String[] args) {
        ArrayOfMul.run();
    }
}
