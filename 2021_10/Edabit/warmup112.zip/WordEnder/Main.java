package Edabit.WordEnder;

public class Main {
   public static void main(String[] args) {
       WordEnding.run();
   } 
}
