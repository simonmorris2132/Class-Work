package InterChallenge.sum;

@SuppressWarnings("ALL")

public class Main {

    public static void main(String[] args) {
        Sum.run();
    }
    
}
