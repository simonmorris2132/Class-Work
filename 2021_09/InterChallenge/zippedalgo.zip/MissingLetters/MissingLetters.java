package InterChallenge.MissingLetters;

@SuppressWarnings("ALL")

public class MissingLetters {

    static String fearNotString(String str) {
        int i = 0;
        int j = 0;
        int k = 122;
        boolean str1;

        if (str) {
            i = str.codePointAt(0);
        }
    }

    public static void run() {
       
    }
}
