package InterChallenge.SearchAndReplace;

@SuppressWarnings("ALL")

public class SearchAndReplace {

    public static void run() {
        
        String searchThru = "The quick brown fox jumped over the brown log.";
        String replaceWith = "leaped";
        System.out.println(searchThru.replaceAll("jumped", replaceWith));
        

    }
    
}
