package InterChallenge.WhereverArtThou;

@SuppressWarnings("ALL")

public class WhereverArtThou {

    static String[][] whereArtThou = {{"Apple", "1"}, {"Bat", "2"}};
    static String[][] compareArtThou = {{"Apple", "1"}};

    public static void run() {
        
        for (int i = 0; i < whereArtThou.length; i++) {
            for (int j = 0; j < compareArtThou.length; j++) {
                
            }
        }

    }
    
}
