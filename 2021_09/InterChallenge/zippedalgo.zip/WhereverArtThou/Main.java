package InterChallenge.WhereverArtThou;

@SuppressWarnings("ALL")

public class Main {
    
}
